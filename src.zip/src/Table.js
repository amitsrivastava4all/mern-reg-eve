import './App.css';
export const Table = ()=>{
    const mystyle = {
        color:'green',
        backgroundColor:'pink'
    }
    return (
        <table className="table table-bordered table-primary">
                <tr className='red'>
                    <td>1001</td>
                    <td style={mystyle}>1001</td>
                </tr>
            </table>
            );
}
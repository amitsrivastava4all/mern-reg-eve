import React from "react";
import { Menu } from "./Menu";
import { Table } from "./Table";

//export function App(){
 export const App = ()=>{
   return (<div className='container'><Menu name='Brain Mentors' home='Delhi' /><Table/></div>);
  //return (<div><h1 className='alert-info'>Hello ReactJS</h1><h2>Hi ReactJS</h2></div>)
  //return React.createElement('div',null, React.createElement('h1',{className:'alert-success'},'Hello ReactJS'),React.createElement('h2',null, 'Hi ReactJS'));
  

} 
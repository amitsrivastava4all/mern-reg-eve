import {App} from './App';
import ReactDOM from 'react-dom';
const div  = document.querySelector('#root');
ReactDOM.render(<App/>, div);
// class Sample extends React.Component {
//   constructor() {
//     super();
//     this.state = {
//       orders: [{}],
//       payment: {},
//       customer: {},
//     };
//   }
//   updateOrder() {
//     this.setState({ ...this.state, orders: [{}, {}] });
//   }
// }

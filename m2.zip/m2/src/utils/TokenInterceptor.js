import axios from "axios";
export function tokenInterceptor() {
  axios.defaults.baseURL = "https://jsonplaceholder.typicode.com";
  axios.defaults.headers.common["API_KEY"] = "ABCDE1111";
  console.log("Interceptor Loaded...");
  const requestInterceptor = axios.interceptors.request.use(
    (request) => {
      // request.tokenId = 122222;
      // request.tokenId = localStorage.mytoken;
      //console.log("Request Interceptor Runs ", request.tokenId);
      return request;
    },
    (err) => {
      console.log("Error in Token Interceptor ", err);
      return Promise.reject(err);
    }
  );
  axios.interceptors.response.use(
    (response) => {
      console.log("Response Interceptor Execute...");
      return response;
    },
    (err) => {
      console.log("Error in Response Interceptor ", err);
      return Promise.reject(err);
    }
  );
  setTimeout(() => {
    axios.interceptors.request.eject(requestInterceptor);
    console.log("Request Interceptor Eject .....");
  }, 10000);
}

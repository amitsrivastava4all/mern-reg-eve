// export async function doAjax() {
//   const URL = process.env.REACT_APP_MUSIC_URL;
//   console.log("URL ", URL);
//   try {
//     const response = await fetch(URL, {
//       method: "GET",
//     });
//     console.log("Response ", response);
//     const json = await response.json();
//     console.log("JSON is ", json);
//     return json;
//   } catch (err) {
//     return err;
//   }
// }
import axios from "axios";

export function doPostCall() {
  const promise = axios.post("/posts", {
    title: "ABCD",
    body: "XYZ",
    id: 1000,
  });
  promise
    .then((response) => console.log("Response POST Rec ", response))
    .catch((err) => console.log("Error Rec ", err));
}
export function callNewsAPI() {
  const instance = axios.create({
    baseURL: "https://newsapi.org/v2",
  });
  const promise = instance.get(
    "/top-headlines?country=in&apiKey=8d40e1cc9a98436fb47c6b4d32520110"
  );
  promise
    .then((response) => {
      console.log("response of news ", response);
    })
    .catch((err) => console.log("Error of News ", err));
}
export function concurrentCalls() {
  const promise = axios.all([axios.get("/posts"), axios.get("/comments")]);
  promise
    .then((responseArray) => console.log("Responses ", responseArray))
    .catch((err) => console.log("Error is ", err));
}

export async function doAjax() {
  const URL = process.env.REACT_APP_MUSIC_URL;
  console.log("URL ", URL);
  // Generic Axios Function
  // axios({
  //   method:'GET', url:URL, timeout: 9000, maxContentLength:20000
  // });
  // axios methods (Specific Way)
  const promise = axios.get(URL, {
    timeout: 9000,
    maxContentLength: 20000,
  });
  return promise;
}

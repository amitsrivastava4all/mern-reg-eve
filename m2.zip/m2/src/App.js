import {
  concurrentCalls,
  doAjax,
  doPostCall,
  callNewsAPI,
} from "./utils/ClientAPI";

const App = () => {
  callNewsAPI();
  doPostCall();
  concurrentCalls();
  const promise = doAjax();
  promise
    .then((response) => {
      console.log("Response is ", response);
    })
    .catch((err) => {
      console.log("Error in Server Talk ", err);
    });
  return <div></div>;
};
export default App;

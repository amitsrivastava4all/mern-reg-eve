

  const firebaseConfig = {
    apiKey: "AIzaSyA7kq3YhV3MknAOwSKSVtZY1D5MUv4O4ao",
    authDomain: "todoapp-feb.firebaseapp.com",
    projectId: "todoapp-feb",
    storageBucket: "todoapp-feb.appspot.com",
    messagingSenderId: "413964398024",
    appId: "1:413964398024:web:56774d6fa65875678d64fd",
    measurementId: "G-K028H6DTMH"
  };
  firebase.initializeApp(firebaseConfig);

  export const db = firebase.firestore();
  console.log(db);

export async function doAjax() {
  const URL = process.env.REACT_APP_MUSIC_URL;
  console.log("URL ", URL);
  try {
    const response = await fetch(URL, {
      method: "GET",
    });
    console.log("Response ", response);
    const json = await response.json();
    console.log("JSON is ", json);
    return json;
  } catch (err) {
    return err;
  }
}

window.addEventListener("load", bindEvents);
function bindEvents() {
  var likeButton = document.getElementById("like"); // Global
  likeButton.addEventListener("click", plus);
}
var counter = 0; // Global
function plus() {
  counter++;
  var span = document.getElementsByTagName("span")[0];
  span.innerHTML = `<i>${counter}</i>`;
  console.log("I am Plus Function " + counter);
}

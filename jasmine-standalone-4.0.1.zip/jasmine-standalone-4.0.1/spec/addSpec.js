// testing
describe('add suite', ()=>{
    beforeAll(()=>{
        console.log('Before suite...');
    });
    afterAll(()=>{
        console.log('After  suite...');
    })
    beforeEach(()=>{
        console.log('Before..');
    })
    afterEach(()=>{
        console.log('After....');
    })
    it('should add 2 numbers',()=>{
        var c = add(10,20);
        expect(30).toBe(c);
    })
    it('should add 3 numbers',()=>{
        var c = add(10,20,30);
        expect(60).toBe(c);
    })
})
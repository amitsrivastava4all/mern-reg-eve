// Logic
function add(x,y,z =0){
    return x + y+z;
}
import { Resume } from "./containers/Resume";

const App = ()=>{
  return (<Resume/>)
}
export default App;
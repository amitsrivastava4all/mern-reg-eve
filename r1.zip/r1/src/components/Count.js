import {Component} from 'react';
// Class based Component
import './Menu.css';
export class Count extends Component{
    constructor(){
        super(); // Parent Class Cons Call
        this.state = {counter:0,cssClass:'mycolor'};
       //this.state = 0;
        console.log('1. I am in Count Component Cons ', this);
    }
    plus(){
        let count = this.state.counter;
        //let count = this.state;
        count++;
        // if(count>=5){
        //     this.setState({counter:count, cssClass:'mycolor2'});
        //     return ;
        // }
        //this.state.counter = count; // Mutate state (BAD)
        this.setState({counter:count});
        // Immutable Way
        console.log('Count is ', count);
    }
    render(){
        console.log('2. I am Inside Render');
        // UI 
        return (<div>
            
            <button onClick={()=>{
                this.plus();
            }} className='btn btn-primary'>Click Me</button>
            <p className={this.state.counter%2==0?'mycolor':'mycolor2'}>Count is {this.state.counter}</p>
        </div>)
    }
}
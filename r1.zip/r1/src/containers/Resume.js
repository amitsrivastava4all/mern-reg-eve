import { Count } from "../components/Count"
import { Menu } from "../components/Menu"
import { MenuData } from "../utils/MenuData"

export const Resume = ()=>{
    const myStyle = {
        color:'red',
        backgroundColor:'cyan'
    }
    
    
   
   // const list = [{name:'Home',icon:'fa-home'},{name:'About',icon:'fa-address-card'},
    //{name:'ContactUs', icon:'fa-phone'}, {name:'News',icon:'fa-car'},{name:'Info', icon:'fa-info'}];
    return (<div className='container'>
            <Count/>
            <h1 className='text-center' style ={myStyle}>Web Resume</h1>
            <Menu companyName='Brain Mentors' list= {MenuData()}/>
    </div>)
}
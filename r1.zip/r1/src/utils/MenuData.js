import {AiFillHome} from 'react-icons/ai';
import {FcAbout} from 'react-icons/fc';
import {IoMdContacts} from 'react-icons/io';
import {BiNews} from 'react-icons/bi';
export const MenuData = ()=>{
    return   [
        {id:101, name:'Home', icon:<AiFillHome/>},
        {id:102, name:'About',icon:<FcAbout/>},
    {id:103, name:'ContactUs', icon:<IoMdContacts/>},
    {id:104, name:'News', icon:<BiNews/>}
    ]
}
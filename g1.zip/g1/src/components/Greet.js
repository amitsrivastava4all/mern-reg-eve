import { Component } from "react";
import { Button } from "../widgets/Button";
import { Input } from "../widgets/Input"
import { Message } from "../widgets/Message";
import {initCap} from '../utils/InitCap';
// Smart Component / Class Base Component
export class Greet extends Component{
    constructor(){
        super();
        // this.firstName = '';
        // this.lastName = '';
        this.names = {first:'', last:''};
       // this.bindEvents();
       this.takeName = this.takeName.bind(this);
        this.state = {message:''};

    }
    // bindEvents(){
    //     this.takeFirstName = this.takeFirstName.bind(this);
    //     this.takeLastName = this.takeFirstName.bind(this);
    // }
    // takeFirstName(event){
    //     console.log('First Name ', event.target.value, ' this is ',this);
    //     this.firstName = event.target.value;
    // }
    // takeLastName(event){
    //     console.log('last Name ', event.target.value, 'this is ',this);
    //     this.lastName = event.target.value;
    // }

    takeName(event, name){
        let value = event.target.value;
        this.names[name] = value;
        console.log('Names ',this.names);
    }

    sayWelcome(){
            let fullName = initCap(this.names.first) +" "+ initCap(this.names.last);
            let message = 'Welcome '+fullName;
            this.setState({message:message});
    }

    clearAll(){

    }

    render(){
        return (<div className='container'>
            <Message message='Greet App'/>
            <Message message={this.state.message}/>
        {/* <Input lbl ='First' input={this.takeFirstName.bind(this)} />
        <Input lbl = 'Last' input = {this.takeLastName.bind(this)}/> */}
         {/* <Input lbl ='First' input={this.takeFirstName} />
        <Input lbl = 'Last' input = {this.takeLastName}/> */}

    {/* <Input lbl ='First' input={(event)=>this.takeFirstName(event)} />
        <Input lbl = 'Last' input = {(event)=>this.takeLastName(event)}/> */}
         <Input lbl ='First' input={this.takeName} />
        <Input lbl = 'Last' input = {this.takeName}/>
        <Button cssClassName='primary' label='Greet' fn= {this.sayWelcome.bind(this)} /> &nbsp;
        <Button cssClassName='secondary' label='Clear All' fn = {this.clearAll.bind(this)} />
    </div>)
    }
}
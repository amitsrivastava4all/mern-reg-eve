export const Message = ({message})=>{
    return (<h2>{message}</h2>)
}
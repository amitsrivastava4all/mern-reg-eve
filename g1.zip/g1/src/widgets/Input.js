// Dumb or Functional Component
export const Input = (props)=>{
    let placeHolder = `Type ${props.lbl} Name Here`;
    return (
    <div className='form-group'>
        <label>{props.lbl} Name</label>
    {/* <input onChange={props.input}  className='form-control' type='text' placeholder={placeHolder}/> */}
    <input onChange={(event)=>{
        props.input(event, props.lbl.toLowerCase());
    }}  className='form-control' type='text' placeholder={placeHolder}/>
    </div>);
}
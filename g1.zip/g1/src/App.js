import React from 'react';
import { Greet } from './components/Greet';

 const App = ()=>{
  return (<Greet/>)
}
export default App;
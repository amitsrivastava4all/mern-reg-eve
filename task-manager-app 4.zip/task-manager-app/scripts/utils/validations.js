export const validate = {
    alphaNumeric(val, errorMessage){
        const pattern = /^[a-z ]+[0-9]+/ig;
        const p = /[a..q]/;
        const p2 = /a*q/;
        const p3 = /[0-9]+/;
        const p4 = /[a-z]{3,10}/;
        return pattern.test(val)?"":errorMessage;
    }
}